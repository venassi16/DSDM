var Banco = function(gerente){
	this.gerente = gerente;
	this.clientes = [];
	this.limite = 5000;
};
var novaConta = function(cpf, nome){
		this.cpf = cpf;
		this.nome = nome;
		this.saldo = 0;
		this.limite = 5000;
		var cliente = {
			cpf: novaConta.cpf,
			nome: novaConta.nome,
			limite: novaConta.limite,
			saldo: novaConta.saldo,
		}
		Banco.clientes.push(cliente);
};

// var cadastra = function(cpf, nome){
// 	var cliente = new novaConta(cpf, nome);
// 	Banco.clientes.push(cliente);
// }

var deposito = function(cpf, valor){
	for (var i = 0; i <= Banco.clientes.length; i++) {
		if (Banco.clientes[i].cpf == cpf){
			clientes[i].saldo += valor;
		};
	};
};




var fechaConta = function(nome){
	for (var i = 0; i <= Banco.clientes.length; i++) {
		if (Banco.clientes[i].nome == nome){
			delete clientes[i];
		};
	};
};


var x = new Banco("Dlc");
var cad = new novaConta(12324, "Jão");
// var fecha = new fechaConta("Jão");
// var dep = new deposito(12324, 4000)




console.log(x.gerente);
console.log(x.clientes);
console.log(x.clientes.length);